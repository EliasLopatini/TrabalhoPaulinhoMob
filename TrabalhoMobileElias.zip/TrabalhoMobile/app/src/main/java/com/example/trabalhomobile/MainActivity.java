package com.example.trabalhomobile;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText edNome;
    private EditText edEmail;
    private EditText edIdade;
    private EditText edDisciplina;
    private EditText ednota1;
    private EditText ednota2;
    private Button btCalcular;
    private Button btLimpar;
    private TextView tvResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //Instanciando a variavel e vinculando ao
        // componentte no arquivo de layout xml

        edNome = findViewById(R.id.edNome);
        edEmail = findViewById(R.id.edEmail);
        edDisciplina = findViewById(R.id.edDisciplina);
        edIdade = findViewById(R.id.edIdade);
        ednota1 = findViewById(R.id.edNota1);
        ednota2 = findViewById(R.id.edNota2);
        btCalcular = findViewById(R.id.btCalcular);
        btLimpar = findViewById(R.id.btLimpar);
        tvResultado = findViewById(R.id.tvResultado);

        btCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarAluno();

            }
        });

        btLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edNome.setText("");
                edEmail.setText("");
                edIdade.setText("");
                edDisciplina.setText("");
                ednota1.setText("");
                ednota2.setText("");
                tvResultado.setText("");
                dadosConcatenados = ""; // Limpa a String
            }
        });


    }




    private String dadosConcatenados = "";

    private void salvarAluno() {
        String msg = "";
        String strNome = edNome.getText().toString().trim();
        String strEmail = edEmail.getText().toString().trim();
        String strDisciplina = edDisciplina.getText().toString().trim();
        String strIdade = edIdade.getText().toString().trim();
        String strNota1 = ednota1.getText().toString().trim();
        String strNota2 = ednota2.getText().toString().trim();

        // Validação dos campos
        if (strNome.isEmpty()) {
            msg += "O campo de nome está vazio.\n";
        }
        if (strEmail.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(strEmail).matches()) {
            msg += "O email é inválido.\n";
        }
        int idade;
        try {
            idade = Integer.parseInt(strIdade);
            if (idade <= 0) {
                msg += "A idade deve ser um número positivo.\n";
            }
        } catch (NumberFormatException e) {
            msg += "A idade deve ser um número válida.\n";
        }

        double nota1 = 0, nota2 = 0;
        try {
            nota1 = Double.parseDouble(strNota1);
            nota2 = Double.parseDouble(strNota2);
            if (nota1 < 0 || nota1 > 10 || nota2 < 0 || nota2 > 10) {
                msg += "As notas devem estar entre 0 e 10.\n";
            }
        } catch (NumberFormatException e) {
            msg += "As notas devem ser numéricas.\n";
        }

        // Se não houver erros, calcula e exibe a média
        if (msg.isEmpty()) {
            double resultado = (nota1 + nota2) / 2;

            // Mensagem de aprovação ou reprovação
            String status = resultado >= 6 ? "Aprovado" : "Reprovado";

            // Adiciona as informações à String
            dadosConcatenados += "Nome: " + strNome +
                    "\nEmail: " + strEmail +
                    "\nIdade: " + strIdade +
                    "\nDisciplina: " + strDisciplina +
                    "\nNotas 1 e 2o Bimestres: " + strNota1 + ", " + strNota2 +
                    "\nMédia: " + resultado +
                    "\nSituação: " + status +
                    "\n-------------------------\n";

            msg = dadosConcatenados; // Atualiza a mensagem com os dados concatenados
        }

        tvResultado.setText(msg);
    }
}